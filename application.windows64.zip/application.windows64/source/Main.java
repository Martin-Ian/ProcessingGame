import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Main extends PApplet {

/********************************
 Ian Martin 2018
 BulletHell Remake
 
 Main.pde
 ********************************/

//Wall arrayList
ArrayList<Entity> walls = new ArrayList<Entity>();
//Player Entity
Player player;
//Enemy arrayList
ArrayList<Entity> enemies = new ArrayList<Entity>();
//Bullet arraylist
ArrayList<Entity> bullets = new ArrayList<Entity>();
//Particles
ArrayList<Entity> particles = new ArrayList<Entity>();
//Camera controls
float cameraX, cameraY;
//Player Controls
boolean isUp, isDown, isRight, isLeft, space;
Stage stage;

public void setup()
{
  

  //Initial camera position
  cameraX = width/4;
  cameraY = height/2;
  textAlign(CENTER);

  //Declare stage
  stage = new Stage();
}

public void draw()
{
  if (stage.firstFrame)
    stage._setup();
  stage._draw();
}

public void drawEntities(ArrayList<Entity> arr)
{
  rectMode(CENTER);
  noStroke();
  for (int i = arr.size() - 1; i >= 0; i--)
  {
    Entity E = arr.get(i);
    E.show();
  }
}

public void updateEntities(ArrayList<Entity> arr)
{
  for (int i = arr.size() - 1; i >= 0; i--)
  {
    Entity E = arr.get(i);
    E.move();
    E.update();
  }
}

//Same as above, but for single entities

public void drawEntities(Entity E)
{
  rectMode(CENTER);
  noStroke();
  E.show();
}

public void updateEntities(Entity E)
{
  E.move();
  E.update();
}

//Function for the camera to follow a specific Entity

public void cameraFollow(Entity E)
{
  if (player.alive)
  {
    cameraX = lerp(cameraX, E.position.x, 0.05f);
    cameraY = lerp(cameraY, E.position.y, 0.05f);
  } else 
  {
    cameraX = lerp(cameraX, stage.Width/2, 0.005f);
    cameraY = lerp(cameraY, stage.Height/2, 0.005f);
  }
}

public void handleCollision()
{
  //  1
  // 3 4
  //  2

  for (Entity E : walls) //For each Wall
  {
    if (player.alive && player.collides(E) != -1)
    {
      switch(player.collides(E))
      {
      case 1:
        player.velocity.y = 0;
        player.position.y -= 2;
        break;
      case 2:
        player.velocity.x = 0;
        player.position.x += 2;
        break;
      case 3:
        player.velocity.y = 0;
        player.position.y += 2;
        break;
      case 4:
        player.velocity.x = 0;
        player.position.x -= 2;
        break;
      }
    }
    for (Entity EN : enemies) //For each Enemy
    {
      if (EN.collides(E) != -1)
      {
        switch(EN.collides(E))
        {
        case 1:
          EN.velocity.y *= -1;
          EN.position.y -= 1;
          break;
        case 2:
          EN.velocity.x *= -1;
          EN.position.x += 1;
          break;
        case 3:
          EN.velocity.y *= -1;
          EN.position.y += 1;
          break;
        case 4:
          EN.velocity.x *= -1;
          EN.position.x -= 1;
          break;
        }
      }
    }
    for (int i = bullets.size() - 1; i >= 0; i--)
    {
      if (E.special == -1 && bullets.get(i).collides(E) != -1)
      {
        bullets.get(i).onRemoval();
        bullets.remove(i);
        continue;
      } else if (E.special == 2 && bullets.get(i).collides(E) != -1)
      {
        switch(bullets.get(i).collides(E))
        {
        case 1:
          bullets.get(i).velocity.y *= -1;
          bullets.get(i).position.y -= 2;
          break;
        case 2:
          bullets.get(i).velocity.x *= -1;
          bullets.get(i).position.x += 2;
          break;
        case 3:
          bullets.get(i).velocity.y *= -1;
          bullets.get(i).position.y += 2;
          break;
        case 4:
          bullets.get(i).velocity.x *= -1;
          bullets.get(i).position.x -= 2;
          break;
        }
      }  
      if (player.alive && bullets.get(i).collides(player) != -1)
      {
        bullets.remove(i);
        player.lives--;
      }
    }
  }


  for (Entity EN : enemies)
  {
    for (Entity ENE : enemies)
    {
      if (EN.collides(ENE) != -1)
      {
        switch(EN.collides(ENE))
        {
        case 1:
          EN.velocity.y *= -1;
          EN.position.y -= 1;
          ENE.velocity.y *= -1;
          ENE.position.y += 1;
          break;
        case 2:
          EN.velocity.x *= -1;
          EN.position.x += 1;
          ENE.velocity.x *= -1;
          ENE.position.x -= 1;
          break;
        case 3:
          EN.velocity.y *= -1;
          EN.position.y += 1;
          ENE.velocity.y *= -1;
          ENE.position.y -= 1;
          break;
        case 4:
          EN.velocity.x *= -1;
          EN.position.x -= 1;
          ENE.velocity.x *= -1;
          ENE.position.x += 1;
          break;
        }
      }
    }
  }

  if (player.lives <= 0)
  {
    player.alive = false;
    player.lives = 1;
    player.velocity.setMag(1);
    for (int i = 0; i < 25; i++)
    {
      Entity P = new Entity(player.position.x, player.position.y);
      P.dimentions.x = 5;
      P.dimentions.y = 5;
      P.filler = player.filler;
      P.velocity.x = random(-2, 2);
      P.velocity.y = random(-2, 2);
      P.velocity.add(player.velocity);
      particles.add(P);
    }
  }

  if (player.alive) {
    for (int i = enemies.size()-1; i >= 0; i--)
    {
      if (player.collides(enemies.get(i)) != -1)
      {
        if (enemies.get(i).parent != null)
          enemies.get(i).parent.children.remove(enemies.get(i));
        enemies.remove(i);
      }
    }
  }
}

//Keyboard input

public void keyPressed() 
{
  setMove(keyCode, true);
}

public void keyReleased() 
{
  setMove(keyCode, false);
}

public boolean setMove(int k, boolean b) 
{
  switch (k) {
  case UP:
  case 'W':
    return isUp = b;

  case LEFT:
  case 'A':
    return isLeft = b;

  case RIGHT:
  case 'D':
    return isRight = b;

  case DOWN:
  case 'S':
    return isDown = b;

  case ' ':
    return space = b;

  default:
    return b;
  }
}

//Helper function...

public float floatLimit(float A, float B)
{
  if (A > B)
    return A;
  else
    return B;
}
/*********************************
 Bullet.pde
 This is the bullet class, when the 
 player gets hit by 3 bullets, they die
 *********************************/

class Bullet extends Entity
{

  Bullet()
  {
    super();
  }

  Bullet(float posX, float posY, float ang)
  {
    super(posX, posY);
    type = "Bullet";
    velocity = PVector.fromAngle(ang);
    velocity.setMag(6);
    filler = color(0, 0, 255);
    dimentions = new PVector(15, 15);
  }

  public void show()
  {
    fill(0);
    rect(position.x, position.y, dimentions.x + 5, dimentions.y + 5);
    fill(filler);
    rect(position.x, position.y, dimentions.x, dimentions.y);
  }
}
/************************************
 Enemy.pde
 
 This class is the basic enemy class
 ************************************/

class Enemy extends Entity //Child of Entity
{
  float speed = 4; //Max speed of entity
  float sight = 1250;  //What is the enimies "range"
  boolean inSight = false;  //Toggles on if the player is near
  int cooldown = 60, maxCoolDown = 60;  //For shooting
  boolean canShoot = true;

  //Constructors
  Enemy()
  {
    super(); 
    filler = color(255, 0, 0);
    type = "Enemy";
  }

  Enemy(float posX, float posY)
  {
    super(posX, posY); 
    filler = color(255, 0, 0);
    type = "Enemy";
  }

  Enemy(float posX, float posY, Mother p)
  {
    super(posX, posY); 
    filler = color(255, 0, 0);
    type = "Enemy";
    parent = p;
  }

  //This is the update function for Enemy
  public void update()
  {
    if (moveable)
      position.add(velocity);
    cooldown--;
    if (inSight)
    {
      if (cooldown < -maxCoolDown/2)
      {
        shoot(atan2(player.position.y - position.y, player.position.x - position.x));
        cooldown = maxCoolDown/2;
      }
    }
  }

  //This says how the Enemy moves
  public void move()
  {
    //see if the player is close
    if (player != null && player.alive && canShoot && dist(player.position.x, player.position.y, position.x, position.y) <= sight/2)
    {
      inSight = true;

      //Apply a velocity towards the player
      if (player.position.x > position.x)
      {
        velocity.x = lerp(velocity.x, speed, 0.01f);
      } else if (player.position.x < position.x)
      {
        velocity.x = lerp(velocity.x, -speed, 0.01f);
      } else 
      {
        velocity.x = lerp(velocity.x, 0, 0.1f);
      }

      if (player.position.y > position.y)
      {
        velocity.y = lerp(velocity.y, speed, 0.01f);
      } else if (player.position.y < position.y)
      {
        velocity.y = lerp(velocity.y, -speed, 0.01f);
      } else 
      {
        velocity.y = lerp(velocity.y, 0, 0.1f);
      }
    } else
    {
      //If player is not close enough, kinda random movement
      //TODO: Clean random movement
      if (canShoot)
        cooldown = maxCoolDown;
      inSight = false;
      velocity.x += random(-0.1f, 0.1f);
      velocity.y += random(-0.1f, 0.1f);
    }
    velocity.limit(speed);
  }

  public void show()
  {
    //How the enemy looks
    fill(filler);
    rect(position.x, position.y, dimentions.x, dimentions.y);
    if (cooldown < 0)
    {
      fill(100, 0, 0);
      rect(position.x, position.y, map(cooldown, 0, -maxCoolDown/2, 0, dimentions.x), map(cooldown, 0, -maxCoolDown/2, 0, dimentions.y));
    }
  }

  //Basic shoot function, shoots one bullet at player
  public void shoot(float ang)
  {
    pushMatrix();
    translate(position.x, position.y);
    bullets.add(new Bullet(position.x, position.y, ang));
    popMatrix();
  }

  public void slowShoot(float ang)
  {
    pushMatrix();
    translate(position.x, position.y);
    bullets.add(new SlowBullet(position.x, position.y, ang));
    popMatrix();
  }
  
  public void splitShoot(float ang)
  {
    pushMatrix();
    translate(position.x, position.y);
    bullets.add(new SplitterBullet(position.x, position.y, ang));
    popMatrix();
  }
}
/*************************
 Entity.pde
 
 This class is the base class for 
 all 'interactable' Objects
 *************************/

class Entity
{
  PVector position;
  String type;
  PVector velocity;
  PVector dimentions;
  int filler; //Optional to replace with a image
  boolean moveable; //An immovable Entity won't be able to have a velocity added to it
  float ID = random(1); //This is used in collision
  int special = -1;
  Mother parent = null;

  //Base default constructor
  Entity()
  {
    position = new PVector(width/2, height/2);
    type = "NONE";
    velocity = new PVector(random(-3, 3), random(-3, 3));
    filler = color(random(255), random(255), random(255));
    dimentions = new PVector(50, 50);
    moveable = true;
  }

  //Constructor with position
  Entity(float posX, float posY)
  {
    position = new PVector(posX, posY);
    type = "NONE";
    velocity = new PVector(0, 0);
    filler = color(random(255), random(255), random(255));
    dimentions = new PVector(50, 50);
    moveable = true;
  }

  //Constructor with position and dimentions
  Entity(float posX, float posY, float dimX, float dimY)
  {
    position = new PVector(posX, posY);
    type = "NONE";
    velocity = new PVector(random(-3, 3), random(-3, 3));
    filler = color(random(255), random(255), random(255));
    dimentions = new PVector(dimX, dimY);
    moveable = true;
  }

  //Constructor with position, dimentions, and velocity
  Entity(float posX, float posY, float dimX, float dimY, float velX, float velY)
  {
    position = new PVector(posX, posY);
    type = "NONE";
    velocity = new PVector(velX, velY);
    filler = color(random(255), random(255), random(255));
    dimentions = new PVector(dimX, dimY);
    moveable = true;
  }

  //Basic collision function, returns if given Entity is colliding with current Entity
  public int collides(Entity E)
  {
    if (this.ID != E.ID)
    {
      float A_top = this.position.y - this.dimentions.y/2;
      float A_right = this.position.x + this.dimentions.x/2;
      float A_bot = this.position.y + this.dimentions.y/2;
      float A_left = this.position.x - this.dimentions.x/2;
      
      float B_top = E.position.y - E.dimentions.y/2;
      float B_right = E.position.x + E.dimentions.x/2;
      float B_bot = E.position.y + E.dimentions.y/2;
      float B_left = E.position.x - E.dimentions.x/2;
      
      if(A_bot > B_top && A_left < B_right && A_right > B_left && this.position.y < B_top)
      {
        return 1;
      }
      if(A_left < B_right && A_top < B_bot && A_bot > B_top && this.position.x > B_right)
      {
        return 2;
      }
      if(A_top < B_bot && A_left < B_right && A_right > B_left && this.position.y > B_bot)
      {
        return 3;
      }
      if(A_right > B_left && A_top < B_bot && A_bot > B_top && this.position.x < B_left)
      {
        return 4;
      }
      
    }
    return -1;
  }

  //Base update function
  public void update()
  {
    if (moveable)
      position.add(velocity);
  }

  //base display function
  public void show()
  {
    fill(filler);
    rect(position.x, position.y, dimentions.x, dimentions.y);
  }
  
  public void onRemoval()
  {
   //Blank 
  }

  public void move()
  {
    //Intentionally blank
  }
}
class Mother extends Enemy
{
  int maxChildren = 7;
  ArrayList<Enemy> children = new ArrayList<Enemy>();

  Mother()
  {
    super();
  }

  Mother(float posX, float posY)
  {
    super(posX, posY); 
    filler = color(255, 133, 3);
    speed = 3;
    type = "Enemy";
    canShoot = true;
    maxCoolDown = 60;
    cooldown = maxCoolDown;
  }

  public void update()
  {
    if (moveable)
      position.add(velocity);
    if (player.alive && children.size() < maxChildren)
    {
      cooldown--;
      if (cooldown < -maxCoolDown/2)
      {
        cooldown = maxCoolDown;
        Enemy E = new Enemy(position.x, position.y, this);
        E.cooldown = 0;
        enemies.add(E);
        children.add(E);
      }
    } else 
    {
      cooldown = maxCoolDown;
    }
  }

  //This says how the Enemy moves
  public void move()
  {
    //see if the player is close
    if (player != null && player.alive && canShoot && dist(player.position.x, player.position.y, position.x, position.y) <= sight/2)
    {
      inSight = true;

      //Apply a velocity towards the player
      if (player.position.x > position.x)
      {
        velocity.x = lerp(velocity.x, -speed, 0.1f);
      } else if (player.position.x < position.x)
      {
        velocity.x = lerp(velocity.x, speed, 0.1f);
      } else 
      {
        velocity.x = lerp(velocity.x, 0, 0.1f);
      }

      if (player.position.y > position.y)
      {
        velocity.y = lerp(velocity.y, -speed, 0.1f);
      } else if (player.position.y < position.y)
      {
        velocity.y = lerp(velocity.y, speed, 0.1f);
      } else 
      {
        velocity.y = lerp(velocity.y, 0, 0.1f);
      }
    } else
    {
      //If player is not close enough, kinda random movement
      //TODO: Clean random movement
      inSight = false;
      velocity.x += random(-0.1f, 0.1f);
      velocity.y += random(-0.1f, 0.1f);
    }
    velocity.limit(speed);
  }
}
/*******************************
 Player.pde
 
 This class is the player class
 *******************************/

class Player extends Entity //This is based off of the Entity class
{
  float baseSpeed = 7, speed = 7;
  int lives = 1;
  boolean alive = true;

  //Default constructor
  Player()
  {
    super();
    filler = color(0, 255, 0);
    velocity.setMag(0);
    type = "Player";
  }

  //Constructor with position
  Player(float posX, float posY)
  {
    super(posX, posY);
    filler = color(0, 255, 0);
    velocity.setMag(0);
    type = "Player";
  }

  //This function governs the movement of the player
  public void move()
  {
    if (isRight)
    {
      velocity.x = lerp(velocity.x, speed, 0.1f);
    } else if (isLeft)
    {
      velocity.x = lerp(velocity.x, -speed, 0.1f);
    } else 
    {
      velocity.x = lerp(velocity.x, 0, 0.1f);
    }

    if (isDown)
    {
      velocity.y = lerp(velocity.y, speed, 0.1f);
    } else if (isUp)
    {
      velocity.y = lerp(velocity.y, -speed, 0.1f);
    } else 
    {
      velocity.y = lerp(velocity.y, 0, 0.1f);
    }
    velocity.limit(speed);
    speed -= 0.01f;
    if (speed < baseSpeed) speed = baseSpeed;
  }

  //Player update function
  public void update()
  {
    if (moveable && alive)
      position.add(velocity);
  }

  //Player show function
  public void show()
  {
    if (alive)
    {
      fill(filler);
      rect(position.x, position.y, dimentions.x, dimentions.y);
    }
  }
}
class SlowEnemy extends Enemy
{
  SlowEnemy()
  {
    super();
  }

  SlowEnemy(float posX, float posY)
  {
    super(posX, posY); 
    filler = color(0xffAB4DF0);
    type = "Enemy";
    canShoot = true;
    maxCoolDown = 40;
    cooldown = maxCoolDown;
  }

  public void update()
  {
    if (moveable)
      position.add(velocity);
    cooldown--;
    if (inSight)
    {
      if (cooldown < -maxCoolDown/2)
      {
        slowShoot(atan2(player.position.y - position.y, player.position.x - position.x) + 0.5f);
        slowShoot(atan2(player.position.y - position.y, player.position.x - position.x) - 0.5f);
        cooldown = maxCoolDown/2;
      }
    }
  }
}
class SlowBullet extends Bullet
{
  SlowBullet()
  {
    super();
  }

  SlowBullet(float posX, float posY, float ang)
  {
    super(posX, posY, ang);
    velocity.setMag(1);
    filler = color(0xff4DA8F0);
  }
}
class SplitEnemy extends Enemy
{
  SplitEnemy()
  {
    super();
  }

  SplitEnemy(float posX, float posY)
  {
    super(posX, posY); 
    filler = color(255);
    type = "Enemy";
    canShoot = true;
    maxCoolDown = 50;
    cooldown = maxCoolDown;
  }

  public void update()
  {
    if (moveable)
      position.add(velocity);
    cooldown--;
    if (inSight)
    {
      if (cooldown < -maxCoolDown/2)
      {
        splitShoot(atan2(player.position.y - position.y, player.position.x - position.x));
        splitShoot(atan2(player.position.y - position.y, player.position.x - position.x) + radians(180));
        cooldown = maxCoolDown/2;
      }
    }
  }
}
class SplitterBullet extends Bullet
{
  SplitterBullet()
  {
    super();
  }

  SplitterBullet(float posX, float posY, float ang)
  {
    super(posX, posY, ang);
    velocity.setMag(6);
    filler = color(0xff7C7474);
  }

  public void onRemoval()
  {
    for (int i = -2; i < 3; i++)
    {
      Bullet B = new SlowBullet(position.x, position.y, atan2(player.position.y - position.y, player.position.x - position.x) + radians(20 * i));
      B.update();
      B.update();
      bullets.add(B);
    }
  }
}
class Sprinkler extends Enemy
{
  Sprinkler()
  {
    super();
  }

  Sprinkler(float posX, float posY)
  {
    super(posX, posY); 
    speed = 1.5f;
    sight = sight*5;
    filler = color(100, 100, 100);
    type = "Enemy";
    canShoot = true;
    maxCoolDown = 360;
    cooldown = 180;
  }

  public void update()
  {
    if (moveable)
      position.add(velocity);
    cooldown++;
    //cooldown = cooldown % maxCoolDown;
    if (inSight && cooldown % 60 == 18)
    {
      shoot(radians(cooldown+30));
      shoot(radians(cooldown+60));
      shoot(radians(cooldown+90));
      shoot(radians(cooldown-30));
      shoot(radians(cooldown-60));
      shoot(radians(cooldown-90));
      shoot(radians(cooldown));
    }
  }

  public void show()
  {
    //How the enemy looks
    fill(filler);
    rect(position.x, position.y, dimentions.x, dimentions.y);
    if (inSight)
    {
      fill(100, 0, 0);
      rect(position.x, position.y, map((cooldown-18)%60, 0, 59, 0, dimentions.x), map((cooldown-18)%60, 0, 59, 0, dimentions.y));
    }
    fill(255, 0, 0);
    rect(position.x + cos(radians(cooldown))*35, position.y + sin(radians(cooldown))*35, 5, 5);
  }
}
/*****************************
 Basic Stage class
 *****************************/

class Stage
{
  int level;
  boolean firstFrame = true;
  int Width, Height;
  Stage()
  {
    level = 0;
    Width = width;
    Height = height;
  }

  Stage(int stagenum)
  {
    level = stagenum;
  }

  public void _setup()
  {
    loadWalls(level);
    firstFrame = false;
  }

  public void _draw()
  {
    background(50);

    updateEntities(particles);
    updateEntities(enemies);
    updateEntities(player);
    updateEntities(bullets);
    handleCollision();
    cameraFollow(player);
    pushMatrix();
    translate(width/2 - cameraX, height/2 - cameraY);
    drawEntities(particles);
    drawEntities(enemies);
    drawEntities(player);
    drawEntities(walls);
    drawEntities(bullets);
    popMatrix();

    if (player.alive == false)
    {
      deathScreen();
    } else if (enemies.size() == 0)
    {
      winScreen();
    }
  }
}

public void deathScreen()
{
  textSize(32);
  fill(255);
  text("You Died!\nPress the 'SPACE-BAR' to restart!", width/2, height/2);
  if (space)
  {
    stageReset();
  }
}

public void winScreen()
{
  for (int i = bullets.size() - 1; i >= 0; i--)
  { 
    bullets.remove(i);
  }
  textSize(30);
  fill(255);
  text("You WON!\nPress the 'SPACE-BAR' to continue!", width/2, height/2);
  if (space)
  {
    stage.level++;
    stageReset();
  }
}

public void loadWalls(int levels)
{
  switch(levels)
  {
  case 0:
    stage.Width = 1000;
    stage.Height = 800;
    player = new Player(stage.Width/4, stage.Height/2);
    enemies.add(new Enemy(stage.Width*3/4, stage.Height/2));
    edges(stage.Width, stage.Height);
    walls.add(new Wall(stage.Width/2, stage.Height/2, 20, stage.Height*2/3, -1));
    break;
  case 1:
    stage.Width = 1000;
    stage.Height = 800;
    player = new Player(stage.Width/4, stage.Height/2);
    enemies.add(new Enemy(stage.Width*3/4, stage.Height/4));
    enemies.add(new Enemy(stage.Width*3/4, stage.Height*3/4));
    edges(stage.Width, stage.Height);
    walls.add(new Wall(stage.Width/2, stage.Height/2, 20, stage.Height*2/3, -1));
    walls.add(new Wall(stage.Width*3/4, stage.Height/2, stage.Width/2, 20, -1));
    break;
  case 2:
    stage.Width = 1000;
    stage.Height = 800;
    player = new Player(stage.Width/4, stage.Height/2);
    enemies.add(new Enemy(stage.Width*2/3, stage.Height/4));
    enemies.add(new Enemy(stage.Width*5/6, stage.Height/4));
    enemies.add(new Trio(stage.Width*2/3, stage.Height*3/4));
    edges(stage.Width, stage.Height);
    walls.add(new Wall(stage.Width/2, stage.Height/2, 20, stage.Height*2/3, -1));
    walls.add(new Wall(stage.Width*3/4, stage.Height/2, stage.Width/2, 20, 1));
    break;
  case 3:
    stage.Width = 1000;
    stage.Height = 800;
    player = new Player(stage.Width/4, stage.Height/2);
    enemies.add(new Trio(stage.Width*2/3, stage.Height/4));
    enemies.add(new Enemy(stage.Width*5/6, stage.Height/4));
    enemies.add(new Trio(stage.Width*2/3, stage.Height*3/4));
    enemies.add(new Enemy(stage.Width*5/6, stage.Height*3/4));
    edges(stage.Width, stage.Height);
    walls.add(new Wall(stage.Width/2, stage.Height/2, 20, stage.Height*2/3, 1));
    walls.add(new Wall(stage.Width*3/4, stage.Height/2, stage.Width/2, 20, 1));
    walls.add(new Wall(stage.Width/8, stage.Height/2, 20, stage.Height/2, 2));
    break;
  case 4:
    stage.Width = 1000;
    stage.Height = 800;
    player = new Player(stage.Width/2, stage.Height/2);
    enemies.add(new Enemy(stage.Width/8, stage.Height/4));
    enemies.add(new Enemy(stage.Width/8, stage.Height*3/4));
    enemies.add(new Enemy(stage.Width*7/8, stage.Height/4));
    enemies.add(new Enemy(stage.Width*7/8, stage.Height*3/4));
    edges(stage.Width, stage.Height);
    walls.add(new Wall(stage.Width/4, stage.Height/2, 20, stage.Height*3/4, 1));
    walls.add(new Wall(stage.Width*3/4, stage.Height/2, 20, stage.Height*3/4, 1));
    walls.add(new Wall(stage.Width/8, stage.Height/2, stage.Width/4, 20, 1));
    walls.add(new Wall(stage.Width*7/8, stage.Height/2, stage.Width/4, 20, 1));
    break;
  case 5:
    stage.Width = 1000;
    stage.Height = 800;
    player = new Player(stage.Width/2, stage.Height/2);
    enemies.add(new Enemy(stage.Width/8, stage.Height/4));
    enemies.add(new Trio(stage.Width/8, stage.Height*3/4));
    enemies.add(new Enemy(stage.Width*7/8, stage.Height/4));
    enemies.add(new Enemy(stage.Width*7/8, stage.Height*3/4));
    enemies.add(new Enemy(stage.Width/2, stage.Height*7/8));
    edges(stage.Width, stage.Height);
    walls.add(new Wall(stage.Width/4, stage.Height/2, 20, stage.Height*3/4, 1));
    walls.add(new Wall(stage.Width*3/4, stage.Height/2, 20, stage.Height*3/4, 1));
    walls.add(new Wall(stage.Width/8, stage.Height/2, stage.Width/4, 20, 2));
    walls.add(new Wall(stage.Width*7/8, stage.Height/2, stage.Width/4, 20, 1));
    walls.add(new Wall(stage.Width/2, stage.Height/4, stage.Width/4, 50, 2));
    walls.add(new Wall(stage.Width/2, stage.Height*3/4, stage.Width/4, 50, 1));
    break;
  case 6:
    stage.Width = 1000;
    stage.Height = 800;
    player = new Player(stage.Width/8, stage.Height/2);
    enemies.add(new Mother(stage.Width/2, stage.Height/2));
    enemies.add(new Trio(stage.Width*3/4, stage.Height/2));
    enemies.add(new Enemy(stage.Width*3/4, stage.Height/10));
    enemies.add(new Enemy(stage.Width*3/4, stage.Height*9/10));
    edges(stage.Width, stage.Height);
    walls.add( new Wall(stage.Width/4, stage.Height/2, 20, stage.Height/2 + 20, 1));
    walls.add( new Wall(stage.Width/2, stage.Height/4, stage.Width/2 + 20, 20, 1));
    walls.add( new Wall(stage.Width/2, stage.Height*3/4, stage.Width/2 + 20, 20, 1));
    break;
  case 7:
    stage.Width = 1000;
    stage.Height = 800;
    player = new Player(stage.Width/8, stage.Height/2);
    enemies.add(new Trio(stage.Width/2, stage.Height/2));
    enemies.add(new SlowEnemy(stage.Width*3/4, stage.Height/2));
    enemies.add(new SlowEnemy(stage.Width*3/4, stage.Height/10));
    enemies.add(new SlowEnemy(stage.Width*3/4, stage.Height*9/10));
    edges(stage.Width, stage.Height);
    walls.add( new Wall(stage.Width/4, stage.Height/2, 20, stage.Height/2 + 20, 1));
    walls.add( new Wall(stage.Width/2, stage.Height/4, stage.Width/2 + 20, 20, 1));
    walls.add( new Wall(stage.Width/2, stage.Height*3/4, stage.Width/2 + 20, 20, 1));
    break;
  case 8:
    stage.Width = 1300;
    stage.Height = 1300;
    player = new Player(stage.Width/8, stage.Height/8);
    enemies.add(new Sprinkler(stage.Width/2, stage.Height/2));
    enemies.add(new Mother(stage.Width/2, stage.Height/4));
    edges(stage.Width, stage.Height);
    walls.add( new Wall(stage.Width/8, stage.Height/2, 20, stage.Height/3 + 20, 2));
    walls.add( new Wall(stage.Width/2, stage.Height/8, stage.Width/3 + 20, 20, 2));
    walls.add( new Wall(stage.Width/2, stage.Height*7/8, stage.Width/3 + 20, 20, 2));
    walls.add( new Wall(stage.Width*7/8, stage.Height/2, 20, stage.Height/3 + 20, 2));
    break;
  case 9:
    stage.Width = 1300;
    stage.Height = 1300;
    player = new Player(stage.Width/8, stage.Height/2);
    enemies.add(new SplitEnemy(stage.Width*3/8, stage.Height/2));
    enemies.add(new SplitEnemy(stage.Width*5/8, stage.Height/2));
    enemies.add(new Sprinkler(stage.Width/2, stage.Height/2));
    edges(stage.Width, stage.Height);
    walls.add( new Wall(stage.Width/4, stage.Height/2, 20, stage.Height/2 + 20, -1));
    walls.add( new Wall(stage.Width/2, stage.Height/4, stage.Width/2 + 20, 20, -1));
    walls.add( new Wall(stage.Width/2, stage.Height*3/4, stage.Width/2 + 20, 20, -1));

    walls.add( new Wall(stage.Width*3/4, stage.Height/2, 20, stage.Height/4 + 20, 1));
    walls.add( new Wall(stage.Width/2, stage.Height*3/8, stage.Width/4 + 20, 20, 1));
    walls.add( new Wall(stage.Width/2, stage.Height*5/8, stage.Width/4 + 20, 20, 1));
    break;
  default:
    stage.level = 0;
    loadWalls(0);
    break;
  }
}

public void stageReset()
{
  for (int i = walls.size() - 1; i >= 0; i--)
  { 
    walls.remove(i);
  }
  for (int i = enemies.size() - 1; i >= 0; i--)
  { 
    enemies.remove(i);
  }
  for (int i = bullets.size() - 1; i >= 0; i--)
  { 
    bullets.remove(i);
  }
  for (int i = particles.size() - 1; i >= 0; i--)
  { 
    particles.remove(i);
  }
  player = null;
  stage.firstFrame = true;
}

public void edges(int W, int H)
{
  walls.add(new Wall(W/2, 0, W + 20, 20, -1));
  walls.add(new Wall(W/2, H, W + 20, 20, -1));
  walls.add(new Wall(0, H/2, 20, H + 20, -1));
  walls.add(new Wall(W, H/2, 20, H + 20, -1));
}
class Trio extends Enemy
{
  Trio()
  {
    super();
  }

  Trio(float posX, float posY)
  {
    super(posX, posY); 
    filler = color(0xff007DFF);
    type = "Enemy";
    canShoot = true;
    maxCoolDown = 90;
    cooldown = maxCoolDown;
  }

  public void update()
  {
    if (moveable)
      position.add(velocity);
    cooldown--;
    if (inSight)
    {
      if (cooldown < -maxCoolDown/2)
      {
        shoot(atan2(player.position.y - position.y, player.position.x - position.x));
        shoot(atan2(player.position.y - position.y, player.position.x - position.x) + 0.5f);
        shoot(atan2(player.position.y - position.y, player.position.x - position.x) - 0.5f);
        cooldown = maxCoolDown/2;
      }
    }
  }
}
/*************************************
 Wall.pde
 
 This class is the wall class. Walls (as of now)
 cannot be moved through by anything. Will add
 special walls that Enemies can shoot through
 *************************************/

class Wall extends Entity //This class is a child of Entity
{
  //Default constructor
  Wall()
  {
    super();
    moveable = false;
    filler = color(0);
    type = "Wall";
  }

  //Constructor with position; wall will be a 50x50 square
  Wall(float posX, float posY)
  {
    super(posX, posY);
    moveable = false;
    filler = color(0);
    type = "Wall";
  }

  //Constructor with position and dimentions
  Wall(float posX, float posY, float dimX, float dimY, int B)
  {
    super(posX, posY, dimX, dimY);
    moveable = false;
    filler = color(0);
    type = "Wall";
    special = B;
  }

  public void show()
  {
    if (special == 1)
    {
      pushMatrix();
      fill(200, 0, 200);
      rect(position.x, position.y, dimentions.x, dimentions.y);
      popMatrix();
    } else if (special == 2)
    {
      pushMatrix();
      fill(0, 200, 200);
      rect(position.x, position.y, dimentions.x, dimentions.y);
      popMatrix();
    } else
    {
      fill(filler);
      rect(position.x, position.y, dimentions.x, dimentions.y);
    }
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Main" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
